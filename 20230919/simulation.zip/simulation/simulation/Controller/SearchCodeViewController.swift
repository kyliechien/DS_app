//
//  SearchCodeViewController.swift
//  simulation
//
//  Created by U10916003 on 2023/9/15.
//

import UIKit
import FirebaseDatabase

class SearchCodeViewController: UIViewController,  UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    let useSearchAPI = searchAPI()
    var githubRepo : [Repository] = []
    var searchCodeSort : String?
    var ref: DatabaseReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        
        ref = Database.database().reference()
        guard let searchKeyword = searchCodeSort else { return }
        useSearchAPI.searchGitHubRepositories(keyword: searchKeyword){ repositories, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            } else {
                if let repositories = repositories {

                    self.githubRepo = repositories
                    
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
            }
        }
        
        
        
//        let object : [String : Any] = ["name": "iOS Academy" as NSObject, "Youtube" : "yes"]
//        ref.child("something").setValue(object)

    }

   
    
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return githubRepo.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "datacell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! SearchCodeTableViewCell

        // Configure the cell...
        cell.titleLabel?.text = githubRepo[indexPath.row].name
        cell.starsLabel?.text = String(githubRepo[indexPath.row].stars)
        cell.authorLabel?.text = githubRepo[indexPath.row].login
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let html_url = githubRepo[indexPath.row].html_url
        if let url = URL(string: html_url){
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func turnBackMenu(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }

}

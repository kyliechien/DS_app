//
//  SearchVideoTableViewController.swift
//  simulation
//
//  Created by U10916003 on 2023/8/29.
//

import UIKit

class SearchVideoViewController: UIViewController,  UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    let useSearchAPI = searchAPI()
    var searchVideoSort : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        guard var searchKeyword = searchVideoSort else { return }

        useSearchAPI.searchYoutubeVideo(keyword: searchKeyword){ newVideo, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
            } else {
                if let newVideo = newVideo {
                        
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
            }
        }
    }

    // MARK: - Table view data source

     func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return useSearchAPI.getVideo().count
    }

    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "youtubeCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! SearchVideoTableViewCell

        // Configure the cell...
        cell.videoTitleLabel?.text = useSearchAPI.getVideo()[indexPath.row].title
        
        cell.videoChannelLabel?.text = useSearchAPI.getVideo()[indexPath.row].channelTitle
        

        
        URLSession.shared.dataTask(with: useSearchAPI.getVideo()[indexPath.row].thumbnailUrl) { data, response, error in
                   if let data = data {
                       DispatchQueue.main.async {
                           if let image = UIImage(data: data) {
                               cell.videoImage.image = image
                           }
                       }
                   }
               }.resume()
        
        
        
        return cell
    }
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let videoId = useSearchAPI.getVideo()[indexPath.row].videoId
        
        guard let youtubeUrl = URL(string: "youtube://\(videoId)") else {
            return
            
        }
        if UIApplication.shared.canOpenURL(youtubeUrl) {
            UIApplication.shared.open(youtubeUrl)
        } else {
            guard let videoUrl = URL(string: "https://www.youtube.com/watch?v=\(videoId)") else { return }
            UIApplication.shared.open(videoUrl)
        }
        
    }
    
    @IBAction func turnBackMenu(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
}

//
//  HomeViewController.swift
//  simulation
//
//  Created by U10916003 on 2023/9/1.
//

import UIKit

class HomepageViewController: UIViewController {

    @IBOutlet var homeButton : UIButton!
    @IBOutlet var learnButton : UIButton!
    @IBOutlet var testButton : UIButton!
    @IBOutlet var profileButton : UIButton!
    @IBOutlet var settingButton : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: - Profile button
        let profileSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let profileSymbolImage = UIImage(systemName: "person.fill", withConfiguration: profileSymbolConfig)
        let profileColoredSymbolImage = profileSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        profileButton.setImage(profileColoredSymbolImage, for: .normal)
        
        // MARK: - Learn button
        let learnSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let learnSymbolImage = UIImage(systemName: "book.fill", withConfiguration: learnSymbolConfig)
        let learnColoredSymbolImage = learnSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        learnButton.setImage(learnColoredSymbolImage, for: .normal)
        
        // MARK: - Home button
        let homeSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let homeSymbolImage = UIImage(systemName: "house.fill", withConfiguration: homeSymbolConfig)
        let homeColoredSymbolImage = homeSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        homeButton.setImage(homeColoredSymbolImage, for: .normal)
        
        // MARK: - Test button
        let testSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let testSymbolImage = UIImage(systemName: "graduationcap.fill", withConfiguration: testSymbolConfig)
        let testColoredSymbolImage = testSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        testButton.setImage(testColoredSymbolImage, for: .normal)
        
        // MARK: Setting button
        let settingSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let settingSymbolImage = UIImage(systemName: "gearshape.fill", withConfiguration: settingSymbolConfig)
        let settingColoredSymbolImage = settingSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        settingButton.setImage(settingColoredSymbolImage, for: .normal)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func goToLearn(_ sender: UIButton){
        self.performSegue(withIdentifier: "toLearnMenu", sender: self)
    }
}

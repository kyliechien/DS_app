//
//  Video.swift
//  simulation
//
//  Created by U10916003 on 2023/8/26.
//

//import Foundation
//
//class Video{
//
//    var title : String
//    var videoId : String
//
//    init(title: String, videoId: String){
//        self.title = title
//        self.videoId = videoId
//    }
//}

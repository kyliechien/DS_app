//
//  QuickSortSourceCode.swift
//  simulation
//
//  Created by WanHsuan on 2023/8/19.
//

import UIKit

class QuickSortSourceCode: UIViewController {
    
    @IBOutlet var text1: UITextField!
    @IBOutlet var text2: UITextField!
    @IBOutlet var text3: UITextField!
    @IBOutlet var text4: UITextField!
    @IBOutlet var text5: UITextField!
    @IBOutlet var text6: UITextField!
    @IBOutlet var text7: UITextField!
    
    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    @IBOutlet var label3: UILabel!
    @IBOutlet var label4: UILabel!
    @IBOutlet var label5: UILabel!
    @IBOutlet var label6: UILabel!
    @IBOutlet var label7: UILabel!
    @IBOutlet var label8: UILabel!
    @IBOutlet var label9: UILabel!
    @IBOutlet var label10: UILabel!
    @IBOutlet var label11: UILabel!
    @IBOutlet var label12: UILabel!
    @IBOutlet var label13: UILabel!
    @IBOutlet var label14: UILabel!
    @IBOutlet var label15: UILabel!
    @IBOutlet var label16: UILabel!
    @IBOutlet var label17: UILabel!

    
    
    @IBOutlet var stepNum: UILabel!
    @IBOutlet var nextStep: UIButton!
    @IBOutlet var preStep: UIButton!
    
    var previousVC: QuickSortSimulation?
    var arr = [Int]()
    var currentStep = 1
    var everyStep = [Int: Array<Int>]()
    var totalStep = 1
    
    var color_bg_highlighter = UIColor(rgb: 0xf5f36c) //螢光筆顏色(底)
    var color_text_highlighter = UIColor(rgb: 0xe31212)
    var color_array_bg = UIColor(rgb: 0xffffff) //陣列底色
    var color_array_text = UIColor(rgb: 0x2B2D42) //陣列數字顏色
    
    @IBOutlet var button1: UIButton! {
        didSet {
            button1.layer.cornerRadius = button1.bounds.width/2
        }
    }
    @IBOutlet var button2: UIButton! {
        didSet {
            button2.layer.cornerRadius = button2.bounds.width/2
        }
    }
    
    @IBOutlet var buttonRandom: UIButton! {
        didSet {
            buttonRandom.layer.cornerRadius = 7
        }
    }
    @IBOutlet var buttonReset: UIButton! {
        didSet {
            buttonReset.layer.cornerRadius = 7
            
        }
    }
    @IBOutlet var buttonTurnPage: UIButton! {
        didSet {
            buttonTurnPage.layer.cornerRadius = 7
        }
    }
    
    @IBAction func turnToQuickSort(_ sender: UIButton) {
        sentDataBack()
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func goToSortＭenu(_ sender: UIButton) {
        performSegue(withIdentifier: "toSortMenu", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if previousVC!.everyStep.isEmpty {
            stepNum.text = "/"
            nextStep.isEnabled = false
            preStep.isEnabled = false

        } else {
            // 傳值
            showCurrArr(everyStep[currentStep]!)
            changeBG(everyStep[currentStep]!)
            changeTextColor(everyStep[currentStep]!)
            changeLabelBG(everyStep[currentStep]!)
            stepNum.text = "\(currentStep) / \(everyStep.count)"

            if(currentStep >= everyStep.count)
            {
                nextStep.isEnabled = false
            }else{
                nextStep.isEnabled = true
            }
            if(currentStep <= 1)
            {
                preStep.isEnabled = false
            }else{
                preStep.isEnabled = true
            }
            
            if let whichStep = everyStep[currentStep]
            {
                if whichStep[whichStep.count - 3] == 13
                {
                    changeTextColor2(whichStep[whichStep.count - 5])
                    
                }
                else if whichStep[whichStep.count - 3] == 14
                {
                    changeTextColor2(whichStep[whichStep.count - 7])
                    
                }
                
            }
        }

    }
    
    func sentDataBack() {
        if previousVC != nil {
            previousVC!.currentStep = currentStep
            
            checkButton()
            previousVC!.totalStep = totalStep
            if everyStep.isEmpty {
                turnBackClear()
                previousVC!.nextStep.isEnabled = false
                previousVC!.preStep.isEnabled = false
                
            } else {
                previousVC!.everyStep = everyStep
                previousVC!.arr = arr
                turnBackChange()
                turnBackChangeBG(everyStep[currentStep]!)
                turnBackChangeTextColor(everyStep[currentStep]!)
                turnBackIntroduceStep(everyStep[currentStep]!)
                turnBackShowIJKey(everyStep[currentStep]!)
                previousVC!.stepNum.text = "\(currentStep) / \(everyStep.count)"
                
                if let whichStep = everyStep[currentStep]
                {
                    if whichStep[whichStep.count - 3] == 13
                    {
                        turnBackChangeTextColor2(whichStep[whichStep.count - 5])
                        
                    }
                    else if whichStep[whichStep.count - 3] == 14
                    {
                        turnBackChangeTextColor2(whichStep[whichStep.count - 7])
                        
                    }
                    
                }
                
                if(currentStep >= everyStep.count)
                {
                    previousVC!.nextStep.isEnabled = false
                }else{
                    previousVC!.nextStep.isEnabled = true
                }
                if(currentStep <= 1)
                {
                    previousVC!.preStep.isEnabled = false
                }else{
                    previousVC!.preStep.isEnabled = true
                }
                if(currentStep == 1)
                {
                    previousVC!.iLabel.text = "i = "
                    previousVC!.jLabel.text = "j = "
                    previousVC!.lLabel.text = "l = "
                    previousVC!.rLabel.text = "r = "
                }
            }
            
            
        }
    }
    
    func checkButton() {
        if(currentStep >= everyStep.count)
        {
            previousVC!.nextStep.isEnabled = false
        }
        if(currentStep <= 1)
        {
            previousVC!.preStep.isEnabled = false
        }
    }
    
    @IBAction func showNumber(sender: UIButton)
    {
        arr.removeAll()
        while arr.count < 7 {
            let randomNumber = Int(arc4random_uniform(10)) + 1
            if !arr.contains(randomNumber) {
                arr.append(randomNumber)
            }
        }
        reset()
        showArr()
        addInformationTodict(arr,-1, -1, -1, -1, -1, -1, -1)
        addInformationTodict(arr,-1, -1, -1, -1, 0, -1, -1)
        quickSort(0, arr.count - 1)
        nextStep.isEnabled = true
        stepNum.text = "\(currentStep) / \(everyStep.count)"
    }
    
    @IBAction func clearText(sender: UIButton)
    {
        text1.text = ""
        text2.text = ""
        text3.text = ""
        text4.text = ""
        text5.text = ""
        text6.text = ""
        text7.text = ""
        reset()
        
    }
    
    func reset()
    {
        preStep.isEnabled = false
        nextStep.isEnabled = false
        
        totalStep = 1
        everyStep.removeAll()
        currentStep = 1
        
        stepNum.text = "/"
        
        text1.backgroundColor = color_array_bg
        text2.backgroundColor = color_array_bg
        text3.backgroundColor = color_array_bg
        text4.backgroundColor = color_array_bg
        text5.backgroundColor = color_array_bg
        text6.backgroundColor = color_array_bg
        text7.backgroundColor = color_array_bg
        
        text1.textColor = color_array_text
        text2.textColor = color_array_text
        text3.textColor = color_array_text
        text4.textColor = color_array_text
        text5.textColor = color_array_text
        text6.textColor = color_array_text
        text7.textColor = color_array_text
        
        label1.backgroundColor = UIColor.white
        label2.backgroundColor = UIColor.white
        label3.backgroundColor = UIColor.white
        label4.backgroundColor = UIColor.white
        label5.backgroundColor = UIColor.white
        label6.backgroundColor = UIColor.white
        label7.backgroundColor = UIColor.white
        label8.backgroundColor = UIColor.white
        label9.backgroundColor = UIColor.white
        label10.backgroundColor = UIColor.white
        label11.backgroundColor = UIColor.white
        label12.backgroundColor = UIColor.white
        label13.backgroundColor = UIColor.white
        label14.backgroundColor = UIColor.white
        label15.backgroundColor = UIColor.white
        label16.backgroundColor = UIColor.white
        label17.backgroundColor = UIColor.white
        
    }
    
    @IBAction func nextStep(sender: UIButton)
    {
        //currentLabelStep += 1
        
        currentStep += 1

        preStep.isEnabled = true
        showCurrArr(everyStep[currentStep]!)
        changeBG(everyStep[currentStep]!)
        changeTextColor(everyStep[currentStep]!)
        changeLabelBG(everyStep[currentStep]!)
//        introduceStep(everyStep[currentStep]!)
        stepNum.text = "\(currentStep) / \(everyStep.count)"
//        showIJKey(everyStep[currentStep]!)
        
        if let whichStep = everyStep[currentStep]
        {
            if whichStep[whichStep.count - 3] == 13
            {
                changeTextColor2(whichStep[whichStep.count - 5])
                
            }
            else if whichStep[whichStep.count - 3] == 14
            {
                changeTextColor2(whichStep[whichStep.count - 7])
                
            }
            
        }
        
        if(currentStep >= everyStep.count)
        {
            nextStep.isEnabled = false
        }
        

    }
    @IBAction func preStep(sender: UIButton)
    {
        currentStep -= 1
        nextStep.isEnabled = true
        showCurrArr(everyStep[currentStep]!)
        changeBG(everyStep[currentStep]!)
        changeTextColor(everyStep[currentStep]!)
        changeLabelBG(everyStep[currentStep]!)
//        introduceStep(everyStep[currentStep]!)
        stepNum.text = "\(currentStep) / \(everyStep.count)"
//        showIJKey(everyStep[currentStep]!)
        
        if let whichStep = everyStep[currentStep]
        {
            if whichStep[whichStep.count - 3] == 13
            {
                changeTextColor2(whichStep[whichStep.count - 5])
                
            }
            else if whichStep[whichStep.count - 3] == 14
            {
                changeTextColor2(whichStep[whichStep.count - 7])
                
            }
            
        }
        
        if(currentStep <= 1)
        {
            preStep.isEnabled = false
        }


    }
    
    func addInformationTodict(_ arr: Array<Int>, _ l: Int, _ r: Int, _ i: Int, _ j: Int, _ step: Int, _ textBGColor: Int, _ textColor: Int)
    {
        var information = [Int](repeating: 0, count: arr.count + 7)
        for index in 0..<arr.count
        {
            information[index] = arr[index]
        }
        information[information.count - 7] = l
        information[information.count - 6] = r
        information[information.count - 5] = i
        information[information.count - 4] = j
        information[information.count - 3] = step
        information[information.count - 2] = textBGColor
        information[information.count - 1] = textColor
        everyStep[totalStep] = information
        totalStep += 1
    }
    
    func quickSort(_ l: Int, _ r: Int)
    {
        //addInformationTodict(arr, -1, -1, 1, -1, -1)
        
        addInformationTodict(arr, l, r, -1, -1, 2, -1, -1)
        if l < r
        {
            var i = l
            addInformationTodict(arr, l, r, i, -1, 3, -1, -1)
            var j = r + 1
            //var x = arr[i]
            addInformationTodict(arr, l, r, i, j, 4, -1, -1)
            
            while i < j
            {
                addInformationTodict(arr, l, r, i, j, 5, -1, -1)
                
                
                var jFirst = true
                repeat
                {
                    if jFirst
                    {
                        jFirst = false
                    }
                    else
                    {
                        addInformationTodict(arr, l, r, i, j, 8, j, -1)
                    }
                    
                    j -= 1 // 从右向左找第一个小于x的数
                    addInformationTodict(arr, l, r, i, j, 7, -1, -1)
                    
                    
                } while i < j && arr[j] > arr[l]
                addInformationTodict(arr, l, r, i, j, 8, j, -1)
                
                var iFirst = true
                repeat
                {
                    if iFirst
                    {
                        iFirst = false
                    }
                    else
                    {
                        addInformationTodict(arr, l, r, i, j, 11, i, -1)
                    }
                    
                    i += 1 // 从右向左找第一个小于x的数
                    addInformationTodict(arr, l, r, i, j, 10, -1, -1)
                    
                } while i < j && arr[i] < arr[l]
                addInformationTodict(arr, l, r, i, j, 11, i, -1)
                            
                
                addInformationTodict(arr, l, r, i, j, 12, -1, -1)
                if i < j
                {
                    let temp = arr[i]
                    arr[i] = arr[j]
                    arr[j] = temp
                    addInformationTodict(arr, l, r, i, j, 13, -1, j)
                    
                }
            }
            addInformationTodict(arr, l, r, i, j, 5, -1, -1)
            
            let tmp = arr[l]
            arr[l] = arr[j]
            arr[j] = tmp
            addInformationTodict(arr, l, r, i, j, 14, -1, j)
            
            

            addInformationTodict(arr, l, r, -1, -1, 15, -1, -1)
            quickSort(l, j - 1)
            addInformationTodict(arr, l, r, -1, -1, 16, -1, -1)
            quickSort(j + 1, r)
            
            addInformationTodict(arr, l, r, -1, -1, 17, -1, -1)
        }
    
    }

    func showCurrArr(_ arr: Array<Int>)
    {
        text1.text = "\(arr[0])"
        text2.text = "\(arr[1])"
        text3.text = "\(arr[2])"
        text4.text = "\(arr[3])"
        text5.text = "\(arr[4])"
        text6.text = "\(arr[5])"
        text7.text = "\(arr[6])"
    }
    
    func showArr()
    {
        text1.text = String(arr[0])
        text2.text = String(arr[1])
        text3.text = String(arr[2])
        text4.text = String(arr[3])
        text5.text = String(arr[4])
        text6.text = String(arr[5])
        text7.text = String(arr[6])
    }
    
    func changeBG(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 2] as! Int
        switch num1
        {
        case 0:
            text1.backgroundColor = color_bg_highlighter
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        case 1:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_bg_highlighter
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        case 2:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_bg_highlighter
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        case 3:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_bg_highlighter
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        case 4:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_bg_highlighter
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        case 5:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_bg_highlighter
            text7.backgroundColor = color_array_bg
        case 6:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_bg_highlighter
        default:
            text1.backgroundColor = color_array_bg
            text2.backgroundColor = color_array_bg
            text3.backgroundColor = color_array_bg
            text4.backgroundColor = color_array_bg
            text5.backgroundColor = color_array_bg
            text6.backgroundColor = color_array_bg
            text7.backgroundColor = color_array_bg
        }
        
    }
    
    func changeTextColor(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 1] as! Int
        switch num1
        {
        case 0:
            text1.textColor = color_text_highlighter
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        case 1:
            text1.textColor = color_array_text
            text2.textColor = color_text_highlighter
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        case 2:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_text_highlighter
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        case 3:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_text_highlighter
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        case 4:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_text_highlighter
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        case 5:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_text_highlighter
            text7.textColor = color_array_text
        case 6:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_text_highlighter
            
        default:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        }
    }
    
    func changeTextColor2(_ num1: Int)
    {
        //var num1 = arr[arr.count - 1] as! Int
        switch num1
        {
        case 0:
            text1.textColor = color_text_highlighter
        case 1:
            text2.textColor = color_text_highlighter
        case 2:
            text3.textColor = color_text_highlighter
        case 3:
            text4.textColor = color_text_highlighter
        case 4:
            text5.textColor = color_text_highlighter
        case 5:
            text6.textColor = color_text_highlighter
        case 6:
            text7.textColor = color_text_highlighter
        default:
            text1.textColor = color_array_text
            text2.textColor = color_array_text
            text3.textColor = color_array_text
            text4.textColor = color_array_text
            text5.textColor = color_array_text
            text6.textColor = color_array_text
            text7.textColor = color_array_text
        }
    }
    
    func turnBackClear ()
    {
        previousVC!.introduce.text = ""
        previousVC!.text1.text = ""
        previousVC!.text2.text = ""
        previousVC!.text3.text = ""
        previousVC!.text4.text = ""
        previousVC!.text5.text = ""
        previousVC!.text6.text = ""
        previousVC!.text7.text = ""
        
        previousVC!.iLabel.text = "i = "
        previousVC!.jLabel.text = "j = "
        previousVC!.lLabel.text = "l = "
        previousVC!.rLabel.text = "r = "
        
        previousVC!.text1.backgroundColor = color_array_bg
        previousVC!.text2.backgroundColor = color_array_bg
        previousVC!.text3.backgroundColor = color_array_bg
        previousVC!.text4.backgroundColor = color_array_bg
        previousVC!.text5.backgroundColor = color_array_bg
        previousVC!.text6.backgroundColor = color_array_bg
        previousVC!.text7.backgroundColor = color_array_bg
        
        previousVC!.text1.textColor = color_array_text
        previousVC!.text2.textColor = color_array_text
        previousVC!.text3.textColor = color_array_text
        previousVC!.text4.textColor = color_array_text
        previousVC!.text5.textColor = color_array_text
        previousVC!.text6.textColor = color_array_text
        previousVC!.text7.textColor = color_array_text
        
        previousVC!.stepNum.text = "/"
    }
    
    func turnBackChange() {
        previousVC!.text1.text = "\(everyStep[currentStep]![0])"
        previousVC!.text2.text = "\(everyStep[currentStep]![1])"
        previousVC!.text3.text = "\(everyStep[currentStep]![2])"
        previousVC!.text4.text = "\(everyStep[currentStep]![3])"
        previousVC!.text5.text = "\(everyStep[currentStep]![4])"
        previousVC!.text6.text = "\(everyStep[currentStep]![5])"
        previousVC!.text7.text = "\(everyStep[currentStep]![6])"
    }
    
    func turnBackChangeBG(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 2] as! Int
        switch num1
        {
        case 0:
            previousVC!.text1.backgroundColor = color_bg_highlighter
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        case 1:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_bg_highlighter
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        case 2:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_bg_highlighter
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        case 3:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_bg_highlighter
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        case 4:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_bg_highlighter
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        case 5:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_bg_highlighter
            previousVC!.text7.backgroundColor = color_array_bg
        case 6:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_bg_highlighter
        default:
            previousVC!.text1.backgroundColor = color_array_bg
            previousVC!.text2.backgroundColor = color_array_bg
            previousVC!.text3.backgroundColor = color_array_bg
            previousVC!.text4.backgroundColor = color_array_bg
            previousVC!.text5.backgroundColor = color_array_bg
            previousVC!.text6.backgroundColor = color_array_bg
            previousVC!.text7.backgroundColor = color_array_bg
        }
        
    }
    
    func turnBackChangeTextColor(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 1] as! Int
        switch num1
        {
        case 0:
            previousVC!.text1.textColor = color_text_highlighter
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        case 1:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_text_highlighter
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        case 2:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_text_highlighter
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        case 3:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_text_highlighter
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        case 4:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_text_highlighter
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        case 5:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_text_highlighter
            previousVC!.text7.textColor = color_array_text
        case 6:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_text_highlighter
            
        default:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        }
    }
    
    func changeLabelBG(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 3] as! Int
        switch num1
        {
        case 0:
            label1.backgroundColor = color_bg_highlighter
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 2:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = color_bg_highlighter
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 3:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = color_bg_highlighter
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 4:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = color_bg_highlighter
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 5:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = color_bg_highlighter
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 7:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = color_bg_highlighter
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 8:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = color_bg_highlighter
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 10:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = color_bg_highlighter
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 11:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = color_bg_highlighter
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 12:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = color_bg_highlighter
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 13:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = color_bg_highlighter
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 14:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = color_bg_highlighter
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        case 15:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = color_bg_highlighter
            label17.backgroundColor = UIColor.white
        case 16:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = color_bg_highlighter
        default:
            label1.backgroundColor = UIColor.white
            label2.backgroundColor = UIColor.white
            label3.backgroundColor = UIColor.white
            label4.backgroundColor = UIColor.white
            label5.backgroundColor = UIColor.white
            label6.backgroundColor = UIColor.white
            label7.backgroundColor = UIColor.white
            label8.backgroundColor = UIColor.white
            label9.backgroundColor = UIColor.white
            label10.backgroundColor = UIColor.white
            label11.backgroundColor = UIColor.white
            label12.backgroundColor = UIColor.white
            label13.backgroundColor = UIColor.white
            label14.backgroundColor = UIColor.white
            label15.backgroundColor = UIColor.white
            label16.backgroundColor = UIColor.white
            label17.backgroundColor = UIColor.white
        }
    }
    
    func turnBackShowIJKey(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 5] as! Int
        
        if num1 != -1
        {
            previousVC!.iLabel.text  = "i = \(num1 + 1)"
        }
        else
        {
            previousVC!.iLabel.text = "i = ?"
        }
        
        var num2 = arr[arr.count - 4] as! Int
        
        if num2 != -1
        {
            previousVC!.jLabel.text = "j = \(num2 + 1)"
        }
        else
        {
            previousVC!.jLabel.text = "j = ?"
        }
        
        var num3 = arr[arr.count - 7] as! Int
        
        if num3 != -1
        {
            previousVC!.lLabel.text = "l = \(num3 + 1)"
        }
        else
        {
            previousVC!.lLabel.text = "l = ?"
        }
        
        
        var num4 = arr[arr.count - 6] as! Int
        
        if num4 != -1
        {
            previousVC!.rLabel.text = "r = \(num4 + 1)"
        }
        else
        {
            previousVC!.rLabel.text = "r = ?"
        }
        
    }
    
    
    
//
//    func turnBackIntroduceStep(_ arr: Array<Int>)
//    {
//        var num1 = arr[arr.count - 3] as! Int
//        switch num1
//        {
//        case 0:
//            previousVC!.introduce.text = "判斷j﻿目前﻿是否﻿小於﻿等於陣列的長度﻿，﻿是則進入﻿迴圈﻿，﻿否則﻿離開"
//        case 1:
//            previousVC!.introduce.text = "﻿將A[j]的值給key"
//        case 2:
//            previousVC!.introduce.text = "﻿將j-1的值給i"
//        case 3:
//            previousVC!.introduce.text = "﻿﻿判斷﻿i是否﻿大於0﻿，﻿且A[i]﻿的﻿值﻿﻿大於key，﻿是則進入﻿迴圈﻿，﻿否則﻿離開"
//        case 4:
//            previousVC!.introduce.text = "﻿將A[i]的值給A[i+1]"
//        case 5:
//            previousVC!.introduce.text = "將i-1的值給i"
//        case 6:
//            previousVC!.introduce.text = "﻿將key的值給A[i+1]"
//        default:
//            previousVC!.introduce.text = ""
//        }
//
//    }
    
    func turnBackIntroduceStep(_ arr: Array<Int>)
    {
        var num1 = arr[arr.count - 3] as! Int
        switch num1
        {
        case 0:
            previousVC!.introduce.text = "﻿呼叫quickSort﻿﻿函式﻿，﻿並﻿將0﻿和﻿A﻿陣列﻿長度﻿的﻿﻿值﻿分﻿別﻿做為l﻿和r"
        case 2:
            previousVC!.introduce.text = "﻿﻿比較l﻿是否﻿﻿小於r"
        case 3:
            previousVC!.introduce.text = "﻿將l的值給i"
        case 4:
            previousVC!.introduce.text = "﻿﻿將r + 1的值給j"
        case 5:
            previousVC!.introduce.text = "﻿判斷i目前﻿是否﻿小於﻿j﻿，﻿是則進入﻿迴圈﻿，﻿否則﻿離開"
        case 7:
            previousVC!.introduce.text = "將j的值﻿﻿減1"
        case 8:
            previousVC!.introduce.text = "﻿判斷目前﻿i是否﻿小於﻿j﻿﻿，﻿且﻿A﻿[﻿j]﻿大於A[l]，﻿是則﻿繼續﻿執行迴圈﻿，﻿否則﻿離開"
        case 10:
            previousVC!.introduce.text = "﻿將i的值﻿﻿加1"
        case 11:
            previousVC!.introduce.text = "判斷目前﻿i是否﻿小於﻿j﻿﻿，﻿且﻿A﻿[﻿j]﻿﻿小於A[l]，﻿是則﻿繼續﻿執行迴圈﻿，﻿否則﻿離開"
        case 12:
            previousVC!.introduce.text = "﻿比較i是否﻿﻿小於j"
        case 13:
            previousVC!.introduce.text = "﻿﻿交換﻿A﻿[﻿i]﻿與A[j]"
        case 14:
            previousVC!.introduce.text = "交換﻿A﻿[﻿l]﻿與A[j]"
        case 15:
            previousVC!.introduce.text = "﻿﻿再次呼叫quickSort﻿﻿函式﻿，﻿並﻿將l和﻿j - 1﻿分﻿別﻿做為l﻿和r"
        case 16:
            previousVC!.introduce.text = "﻿﻿再次呼叫quickSort﻿﻿函式﻿，﻿並﻿將j + 1和﻿r﻿分﻿別﻿做為l﻿和r"
        case 17:
            previousVC!.introduce.text = "﻿﻿﻿結束﻿A﻿[l﻿]~﻿A﻿[r﻿]﻿的﻿排序"
        default:
            previousVC!.introduce.text = ""
        }
        
    }
    
    func turnBackChangeTextColor2(_ num1: Int)
    {
        //var num1 = arr[arr.count - 1] as! Int
        switch num1
        {
        case 0:
            previousVC!.text1.textColor = color_text_highlighter
        case 1:
            previousVC!.text2.textColor = color_text_highlighter
        case 2:
            previousVC!.text3.textColor = color_text_highlighter
        case 3:
            previousVC!.text4.textColor = color_text_highlighter
        case 4:
            previousVC!.text5.textColor = color_text_highlighter
        case 5:
            previousVC!.text6.textColor = color_text_highlighter
        case 6:
            previousVC!.text7.textColor = color_text_highlighter
        default:
            previousVC!.text1.textColor = color_array_text
            previousVC!.text2.textColor = color_array_text
            previousVC!.text3.textColor = color_array_text
            previousVC!.text4.textColor = color_array_text
            previousVC!.text5.textColor = color_array_text
            previousVC!.text6.textColor = color_array_text
            previousVC!.text7.textColor = color_array_text
        }
    }

    
    

    
}

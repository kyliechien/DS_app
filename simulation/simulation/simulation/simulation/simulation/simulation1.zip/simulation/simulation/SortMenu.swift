//
//  SortMenu.swift
//  simulation
//
//  Created by WanHsuan on 2023/8/3.
//

//import Foundation
import UIKit



class SortMenu: UIViewController {
    
    @IBOutlet var homeButton_sort : UIButton!
    @IBOutlet var learnButton_sort : UIButton!
    @IBOutlet var testButton_sort : UIButton!
    @IBOutlet var profileButton_sort : UIButton!
    @IBOutlet var settingButton_sort : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: - Profile button
        let profileSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let profileSymbolImage = UIImage(systemName: "person.fill", withConfiguration: profileSymbolConfig)
        let profileColoredSymbolImage = profileSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        profileButton_sort.setImage(profileColoredSymbolImage, for: .normal)
        
        // MARK: - Learn button
        let learnSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let learnSymbolImage = UIImage(systemName: "book.fill", withConfiguration: learnSymbolConfig)
        let learnColoredSymbolImage = learnSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        learnButton_sort.setImage(learnColoredSymbolImage, for: .normal)
        
        // MARK: - Home button
        let homeSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let homeSymbolImage = UIImage(systemName: "house.fill", withConfiguration: homeSymbolConfig)
        let homeColoredSymbolImage = homeSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        homeButton_sort.setImage(homeColoredSymbolImage, for: .normal)
        
        // MARK: - Test button
        let testSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let testSymbolImage = UIImage(systemName: "graduationcap.fill", withConfiguration: testSymbolConfig)
        let testColoredSymbolImage = testSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        testButton_sort.setImage(testColoredSymbolImage, for: .normal)
        
        // MARK: Setting button
        let settingSymbolConfig = UIImage.SymbolConfiguration(pointSize: 50.0)
        let settingSymbolImage = UIImage(systemName: "gearshape.fill", withConfiguration: settingSymbolConfig)
        let settingColoredSymbolImage = settingSymbolImage?.withTintColor(.black, renderingMode: .alwaysOriginal)
        
        settingButton_sort.setImage(settingColoredSymbolImage, for: .normal)
    }
    
    @IBAction func goToCountingSortSimulation(_ sender: UIButton) {
        performSegue(withIdentifier: "toCountingSortSimulation", sender: self)
    }
    
    @IBAction func goToInsertionSortSimulation(_ sender: UIButton) {
        performSegue(withIdentifier: "toInsertionSortSimulation", sender: self)
    }
    
    @IBAction func goToQuickSortSimulation(_ sender: UIButton) {
        performSegue(withIdentifier: "toQuickSortSimulation", sender: self)
    }
    
    
    @IBAction func goToMergeSortSimulation(_ sender: UIButton) {
        performSegue(withIdentifier: "toMergeSortSimulation", sender: self)
    }
    
    @IBAction func goToCodeSearch(_ sender: UIButton) {
            self.performSegue(withIdentifier: "toSearchCode", sender: self)
        }

    @IBAction func goToVideoSearch(_ sender: UIButton){
        self.performSegue(withIdentifier: "toSearchVideo", sender: self)
    }

    @IBAction func backToHomepage(_ sender: UIButton){
        self.dismiss(animated: true,completion: nil)
    }
}
